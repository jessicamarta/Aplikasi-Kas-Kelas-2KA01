package koneksi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Koneksi {
    private static Connection connection;
    private static final Logger logger = Logger.getLogger(Koneksi.class.getName());

    public static Connection getConnection() {
        if (connection == null) {
            try {
                String url = "jdbc:mysql://localhost:3307/app_kas";
                String user = "root";
                String pass = "";
                DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
                connection = DriverManager.getConnection(url, user, pass);
            } catch (SQLException ex) {
                logger.log(Level.SEVERE, "Connection failed", ex);
            }
        }
        return connection;
    }
}
